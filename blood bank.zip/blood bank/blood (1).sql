-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2023 at 06:46 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blood`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `password`) VALUES
(1, 'chandani', 'chand123');

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE `collection` (
  `donorid` int(11) NOT NULL,
  `hospital` varchar(20) NOT NULL,
  `bags` varchar(7) NOT NULL,
  `date` date NOT NULL,
  `incharge` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `collection`
--

INSERT INTO `collection` (`donorid`, `hospital`, `bags`, `date`, `incharge`) VALUES
(27, 'sant hospital', '5', '2022-02-12', 'doctor bina'),
(39, 'radhe hospital', '5', '2022-02-12', 'nisha doctor'),
(44, 'aasta hospital', '5', '2023-02-01', ' bina');

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE `donor` (
  `id` int(11) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `age` varchar(5) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `blood_type` varchar(5) NOT NULL,
  `remark` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`id`, `fullname`, `address`, `contact`, `email`, `age`, `gender`, `blood_type`, `remark`) VALUES
(27, 'solanki chandni', 'jamnager rode rajkotttt', '4895612387', 'solankichandani@gmail.com', '18', 'male', 'O+', 'fine'),
(39, 'rohan rathod', 'jamnager rode rajkotttt', '4895612387', 'solankichandani@gmail.com', '18', 'male', 'AB+', 'fine'),
(44, 'bhumi solanki', 'balak hanuman seri no 5', '8780563202', 'bhumi@gmail.com', '20', 'female', 'O+', 'fine'),
(45, 'shruti rathod', 'balak hanuman seri no 6', '8780670256', 'shruti@gmail.com', '20', 'Female', 'B+', 'fine'),
(46, 'jyoti parmarrr', 'ratan par rajkot ,36003', '452637891', 'jyoti@gmail.com', '18', 'male', 'B-', 'fine'),
(47, 'solanki chandni', 'chunarawad chock', '8780690259', 'solankichandani@gmail.com', '22', 'Female', 'O+', 'fine');

-- --------------------------------------------------------

--
-- Table structure for table `issued`
--

CREATE TABLE `issued` (
  `id` int(100) NOT NULL,
  `issued_by` varchar(100) NOT NULL,
  `issued_to` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `amount` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issued`
--

INSERT INTO `issued` (`id`, `issued_by`, `issued_to`, `date`, `amount`) VALUES
(1111113, 'bhumi', 'rohan', '2022-02-01', 1200),
(1111114, 'bhumiiii', 'chandniii', '2023-04-15', 1200),
(1111115, 'chandani', 'rohan', '2023-04-18', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` int(10) NOT NULL,
  `email` varchar(15) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `name`, `contact`, `email`, `message`) VALUES
(3, 'akash rathod', 2147483647, 'rohan@gmail.com', 'requrd to blood B+');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `req_id` int(20) NOT NULL,
  `patient_name` varchar(30) NOT NULL,
  `date_request` varchar(10) NOT NULL,
  `blood_type` varchar(5) NOT NULL,
  `bags` int(5) NOT NULL,
  `amout` int(140) NOT NULL,
  `purpose` varchar(20) NOT NULL,
  `remark` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`req_id`, `patient_name`, `date_request`, `blood_type`, `bags`, `amout`, `purpose`, `remark`) VALUES
(1111113, 'riya solanki', '2022-12-13', 'B+', 1, 4000, 'ASAP', 'asap'),
(1111114, 'akash rathod', '2023-04-15', 'AB+', 0, 2000, 'ASAP', ''),
(1111115, 'solanki chandani', '2023-04-18', 'A+', 3, 2000, 'ASAP', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`donorid`);

--
-- Indexes for table `donor`
--
ALTER TABLE `donor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issued`
--
ALTER TABLE `issued`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`req_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `collection`
--
ALTER TABLE `collection`
  MODIFY `donorid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `donor`
--
ALTER TABLE `donor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `issued`
--
ALTER TABLE `issued`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1111116;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `req_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1111116;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
