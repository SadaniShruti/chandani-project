<?php
	require "config.php";
	$id=$_GET['id'];
	$sql="DELETE FROM `collection` WHERE donorid='$id'";
	mysqli_query($con,$sql);
	header("location:bloodcollection.php");
?>

