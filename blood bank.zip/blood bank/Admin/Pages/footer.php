<!-- footer strat-->
	<style>
				footer {
		  text-align: center;
		  padding: 10px;
		  font-size:20px;
		  background-color:black;
		  color: white;
		}
	</style>
		<footer>
		  <p>DEVLOPER: SOLANKI CHANDANI<br>
		  <a href="mailto:hege@example.com">solankichandani@gmail.com</a></p>
		</footer>
<!-- footer end-->