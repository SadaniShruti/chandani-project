<?php
								require "config.php";
								if(isset($_REQUEST['update_btn']))
								{
									$no=$_REQUEST['no'];
									$by=$_REQUEST['by'];
									$to=$_REQUEST['to'];
									$date=$_REQUEST['date'];
									$amt=$_REQUEST['amt'];
									echo $update="UPDATE `issued` SET `issued_by`='$by',`issued_to`='$to',`date`='$date',`amount`='$amt' WHERE id=$no";
									mysqli_query($con,$update);
									header("location:bloodissued.php");
								}
									?>