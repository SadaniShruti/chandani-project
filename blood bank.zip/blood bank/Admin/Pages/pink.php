<!--<button class="btn btn-info btn-xs btn-custon-rounded-three" data-toggle="modal" data-target="#staticBackdrop" 
											data-bs-nm="<?php echo $row['fullname']; ?>" 
											data-bs-add="<?php echo $row['address']; ?>"
											data-bs-cno="<?php echo $row['contact']; ?>"
											data-bs-email="<?php echo $row['email']; ?>"
											data-bs-age="<?php echo $row['age']; ?>"
											data-bs-gen="<?php echo $row['gender']; ?>"
											data-bs-blood="<?php echo $row['blood_type']; ?>"
											data-bs-re="<?php echo $row['remark']; ?>"
											data-bs-id="<?php echo $row['id'];?>" ><i class="fa fa-edit"></i></button> 
											
											
<div id="staticBackdrop" class="modal modal-adminpro-general Customwidth-popup-WarningModal   modal-zoomInDown fade" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"> 
								 
									<div class="modal-dialog">
										<div class="modal-content">
															<div class="modal-close-area modal-close-df">
																<a class="close" data-dismiss="modal" href="#"><i class="fa fa-close"></i></a>
															</div>
															<div class="modal-body">
																<div class="modal-login-form-inner">
																	<div class="row">
																		<div class="col-lg-12">
																			<div class="basic-login-inner modal-basic-inner">
																				<h3 align="center" id="staticBackdropLabel" >Edit Donor</h3>
																				<form action="donor.php" method="POST">
																					<div class="form-group-inner">
																						<div class="row">
																							<div class="col-lg-6">
																								<label class="login2">Fullname</label>
																								
																								<input type="text" name="tfullname" id="fulnm" class="form-control" placeholder="Enter Donor Fullname" />
																								<input type="text" name="txtid" class="form-control" id="txtid" hidden>
																							</div>
																							<div class="col-lg-6">
																								<label class="login2">Address</label>
																								<input type="text" name="taddress" id="addre" class="form-control" placeholder="Enter Donor Address" />
																							</div>
																						</div>
																					</div>
																				<div class="form-group-inner">
																					<div class="row">
																						<div class="col-lg-6">
																							<label class="login2">Contact</label>
																							<input type="text" name="contact" id="conn" class="form-control" placeholder="Enter Donor Contact" />
																						</div>
																						<div class="col-lg-6">
																							<label class="login2">Email Address</label>
																							<input type="email" name="temail" id="emaill" class="form-control" placeholder="Enter Donor Email Address" required />
																						</div>
																					</div>
																				</div>
																				<div class="form-group-inner">
																					<div class="row">
																						<div class="col-lg-3">
																							<label class="login2">Age</label>
																							<input type="number" name="tage" id="agee" class="form-control" placeholder="Age" />
																						</div>
                                                                                    <div class="col-lg-3">
                                                                                        <label class="login2">Gender</label>
                                                                                    <select class="form-control custom-select-value" id="gend" name="taccount">
                                                                                        <option>Male</option>
                                                                                        <option>Female</option>
                                                                                    </select>
                                                                                </div>
                                                                                <div class="col-lg-3">
                                                                                        <label class="login2">Blood</label>
                                                                                    <select class="form-control custom-select-value" id="bltyp" name="taccount1">
                                                                                        <option>O+</option>
                                                                                        <option>O-</option>
																						<option>A+</option>
                                                                                        <option>A-</option>
																						<option>B+</option>
                                                                                        <option>B-</option>
																						<option>AB+</option>
                                                                                        <option>AB-</option>
                                                                                    </select>
                                                                                </div>
                                                                                <div class="col-lg-3">
                                                                                        <label class="login2">Remarks</label>
                                                                                        <input type="text" name="tremarkk" class="form-control" id="remark" placeholder="Remarks" />
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="login-btn-inner" style="margin-left: 8%">
                                                                                <div class="row">
                                                                                    <div class="col-lg-4"></div>
                                                                                    <div class="col-lg-8">
                                                                                        <div class="login-horizental">
                                                                                            <button class="btn btn-sm btn-warning"  type="submit" style="background-color: #f39c12; color: #fff" ><i class="fa fa-pencil"></i> Change</button>
																							
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
										</div>
<script>
	const exampleModal = document.getElementById('staticBackdrop')
	exampleModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget
    const nm = button.getAttribute('data-bs-nm')
    const add = button.getAttribute('data-bs-add')
	const cno = button.getAttribute('data-bs-cno')
	const email = button.getAttribute('data-bs-email')
	const age = button.getAttribute('data-bs-age')
	const gen = button.getAttribute('data-bs-gen')
	const blood = button.getAttribute('data-bs-blood')
	const re = button.getAttribute('data-bs-re')
    const id = button.getAttribute('data-bs-id')
    const modalTitle = exampleModal.querySelector('.modal-title')
	modalTitle.textContent = `Update Record ID ${id}`
    document.getElementById('fulnm').value = nm;
	document.getElementById('addre').value = add;
	document.getElementById('conn').value = cno;
	document.getElementById('emaill').value = email;
	document.getElementById('agee').value = age;
	document.getElementById('gend').value = gen;
	document.getElementById('bltyp').value = blood;
	document.getElementById('remark').value = re;
	document.getElementById('id').value = id;
})
</script> -->
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<p>Current Date and Time is <span id='date-time'></span>.</p>
</body>
</html>
<script>
var dt = new Date();
document.getElementById('date-time').innerHTML=dt;
</script>