<?php
	require "config.php";
	$id = $_GET['id'];
	$sql="DELETE FROM `request` WHERE req_id ='$id'";
	mysqli_query($con,$sql);
	header("location:bloodrequest.php");
?>

