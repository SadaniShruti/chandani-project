<?php
	require "config.php";
	 $id=$_GET['id'];
	$sql="DELETE FROM `donor` WHERE id='$id'";
	mysqli_query($con,$sql);
	header("location:donor.php");
?>

