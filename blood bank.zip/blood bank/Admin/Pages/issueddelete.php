<?php
	require "config.php";
	 $id=$_GET['id'];
	$sql="DELETE FROM `issued` WHERE id='$id'";
	mysqli_query($con,$sql);
	header("location:bloodissued.php");
?>

